# Git 提交历史恢复

history.bundle 保存已获取的上游分支、标签及历史对象，也保留控制库 master 的历史。
不包含 LFS 实际文件、子模块仓库或 GitHub Issues/PR 等平台数据。

安装 Git 后，在本文件所在目录执行（使用新的恢复目录）：

```sh
git clone --mirror history.bundle restored.git
git --git-dir=restored.git fsck --full
git --git-dir=restored.git update-ref refs/heads/restored-source d1eff01eb6ce647d6ea77bb5cbcc964d1e9dd2e7
git --git-dir=restored.git symbolic-ref HEAD refs/heads/restored-source
git clone restored.git restored-worktree
git -C restored-worktree log --oneline
```

直接解压的源码可立即查看；恢复后的 restored-worktree 含 .git 与提交历史。
